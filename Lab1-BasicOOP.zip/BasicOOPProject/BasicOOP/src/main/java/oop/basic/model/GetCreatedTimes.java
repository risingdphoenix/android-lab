package oop.basic.model;

/**
 * Created by USER on 9/8/2556.
 */
public interface GetCreatedTimes {
    public int getAllClassCreatedTimes();
    public int getClassCreatedTimes();
}
